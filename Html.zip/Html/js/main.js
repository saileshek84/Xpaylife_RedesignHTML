// A $( document ).ready() block.
$( document ).ready(function() {
  //  alert();
});
$( window ).load(function() {
  // Run code
});